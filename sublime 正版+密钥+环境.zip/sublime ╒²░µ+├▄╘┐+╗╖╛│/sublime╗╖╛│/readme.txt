1、把压缩包里的Sublime Text 3解压到需要迁移环境的preferences->Browse Packages 的上层目录下，全部覆盖。
2、把ctags58文件夹放到D盘根目录下
3、重启sublime，在打开的文件或文件夹上点击右键Ctag：rebuild tags 
然后就可以享用了。